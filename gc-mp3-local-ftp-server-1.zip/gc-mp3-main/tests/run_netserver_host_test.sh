#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
TMP=${TMPDIR:-/tmp}/gcmp3-netserver-test-$$
trap 'rm -f "$TMP"' EXIT
cc -std=gnu99 -Wall -Wextra -Werror -Wno-unused-parameter -I"$ROOT/tests/mock" -I"$ROOT/source" \
  "$ROOT/tests/netserver_host_test.c" -o "$TMP"
"$TMP"
echo "OK: serveur FTP hote compilable; resolution des chemins et anti-traversal testes."
