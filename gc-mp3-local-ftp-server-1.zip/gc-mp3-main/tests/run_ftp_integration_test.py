#!/usr/bin/env python3
import ftplib, os, pathlib, shutil, socket, subprocess, tempfile, time
root = pathlib.Path(__file__).resolve().parent.parent
with tempfile.TemporaryDirectory(prefix='gcmp3-ftp-it-') as td:
    work = pathlib.Path(td)
    (work / 'sd:' / 'mp3').mkdir(parents=True)
    (work / 'sd:' / 'mp3' / 'existing.txt').write_text('hello from GameCube side')
    exe = work / 'ftp-host-test'
    cmd = ['cc','-std=gnu99','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-pthread',
           '-I'+str(root/'tests/host_server_mock'), '-I'+str(root/'source'),
           str(root/'tests/netserver_host_runtime.c'), '-o', str(exe)]
    subprocess.run(cmd, check=True)
    proc = subprocess.Popen([str(exe)], cwd=work, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    try:
        deadline = time.time() + 5
        while time.time() < deadline:
            try:
                with socket.create_connection(('127.0.0.1',2121),timeout=.2): break
            except OSError: time.sleep(.05)
        else:
            proc.terminate(); time.sleep(.1)
            raise RuntimeError('FTP control port did not start; server stderr='+str(proc.stderr.read()))
        ftp = ftplib.FTP()
        ftp.connect('127.0.0.1',2121,timeout=3)
        ftp.login('gc-mp3','indigo')
        ftp.cwd('/mp3')
        names = ftp.nlst()
        assert 'existing.txt' in names, names
        payload = b'upload test\x00binary\xff'
        from io import BytesIO
        ftp.storbinary('STOR upload.bin', BytesIO(payload))
        out = BytesIO(); ftp.retrbinary('RETR upload.bin', out.write)
        assert out.getvalue() == payload, out.getvalue()
        ftp.rename('upload.bin','renamed.bin')
        assert 'renamed.bin' in ftp.nlst()
        ftp.delete('renamed.bin')
        ftp.mkd('newdir')
        ftp.rmd('newdir')
        ftp.quit()
        bad = ftplib.FTP(); bad.connect('127.0.0.1',2121,timeout=3)
        try: bad.login('bad','bad'); raise AssertionError('bad credentials accepted')
        except ftplib.error_perm: pass
        bad.close()
        print('OK: FTP local integration (login, LIST/NLST, upload binaire, download, rename, delete, MKD/RMD, auth).')
    finally:
        proc.terminate()
        try: proc.wait(timeout=2)
        except subprocess.TimeoutExpired: proc.kill()
