#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include "netserver.c"
s32 net_send(s32 fd,const void *b,s32 n,int f) { return (s32)send(fd,b,(size_t)n,f|MSG_NOSIGNAL); }
s32 net_recv(s32 fd,void *b,s32 n,int f) { return (s32)recv(fd,b,(size_t)n,f); }
s32 net_socket(int a,int b,int c) { return (s32)socket(a,b,c); }
s32 net_connect(s32 fd,struct sockaddr *a,int n) { return (s32)connect(fd,a,(socklen_t)n); }
s32 net_close(s32 fd) { return (s32)close(fd); }
s32 net_bind(s32 fd,struct sockaddr *a,socklen_t n) { int r=bind(fd,a,n); if(r<0) fprintf(stderr,"bind errno=%d port=%u family=%d\n",errno,(unsigned)ntohs(((struct sockaddr_in*)a)->sin_port),a->sa_family); return (s32)r; }
s32 net_listen(s32 fd,int n) { return (s32)listen(fd,n); }
s32 net_accept(s32 fd,struct sockaddr *a,socklen_t *n) { return (s32)accept(fd,a,n); }
s32 net_setsockopt(s32 fd,int l,int o,const void *v,socklen_t n) { return (s32)setsockopt(fd,l,o,v,n); }
int main(void) { if (!gcmp3_ftp_server_start("127.0.0.1")) return 2; sleep(20); return 0; }
