#include <assert.h>
#include <string.h>
#include <sys/socket.h>
#include "netserver.c"
s32 net_send(s32 fd,const void *b,s32 n,int f) {(void)fd;(void)b;(void)f;return n;}
s32 net_recv(s32 fd,void *b,s32 n,int f) {(void)fd;(void)b;(void)n;(void)f;return -1;}
s32 net_socket(int a,int b,int c) {(void)a;(void)b;(void)c;return 3;}
s32 net_connect(s32 fd,struct sockaddr *a,int n) {(void)fd;(void)a;(void)n;return -1;}
s32 net_close(s32 fd) {(void)fd;return 0;}
s32 net_bind(s32 fd,struct sockaddr *a,socklen_t n) {(void)fd;(void)a;(void)n;return 0;}
s32 net_listen(s32 fd,int n) {(void)fd;(void)n;return 0;}
s32 net_accept(s32 fd,struct sockaddr *a,socklen_t *n) {(void)fd;(void)a;(void)n;return -1;}
s32 net_setsockopt(s32 fd,int l,int o,const void *v,socklen_t n) {(void)fd;(void)l;(void)o;(void)v;(void)n;return 0;}
int main(void) {
 char out[768];
 assert(map_path("/", "", out, sizeof(out)) && strcmp(out,"sd:/")==0);
 assert(map_path("/mp3", "song.mp3", out, sizeof(out)) && strcmp(out,"sd:/mp3/song.mp3")==0);
 assert(map_path("/", "/downloads/test.zip", out, sizeof(out)) && strcmp(out,"sd:/downloads/test.zip")==0);
 assert(!map_path("/", "../escape", out, sizeof(out)));
 assert(!map_path("/mp3", "sub/../../escape", out, sizeof(out)));
 assert(!map_path("/", "sd:/bad", out, sizeof(out)));
 assert(!map_path("/", "bad\\path", out, sizeof(out)));
 return 0;
}
