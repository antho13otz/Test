#include <assert.h>
#include <stdint.h>
#include <string.h>
#include <sys/socket.h>
#include "netfiles.h"
typedef int32_t s32;
static const char *rx_data = "";
static size_t rx_pos = 0;
static char tx_data[2048];
static size_t tx_len = 0;
s32 net_send(s32 fd,const void *b,s32 n,int f) {
    (void)fd;(void)f;
    if (n <= 0 || tx_len + (size_t)n >= sizeof(tx_data)) return -1;
    memcpy(tx_data + tx_len, b, (size_t)n); tx_len += (size_t)n; tx_data[tx_len] = 0;
    return n;
}
s32 net_recv(s32 fd,void *b,s32 n,int f) {
    (void)fd;(void)f;
    if (n <= 0 || !rx_data[rx_pos]) return 0;
    size_t left = strlen(rx_data + rx_pos), take = (size_t)n < left ? (size_t)n : left;
    memcpy(b, rx_data + rx_pos, take); rx_pos += take; return (s32)take;
}
s32 net_socket(int a,int b,int c) {(void)a;(void)b;(void)c;return 5;}
s32 net_connect(s32 fd,struct sockaddr *a,int n) {(void)fd;(void)a;(void)n;return 0;}
s32 net_close(s32 fd) {(void)fd;return 0;}
int main(void) {
    assert(nf_protocol_available(NF_PROTO_FTP) == 1);
    assert(nf_protocol_available(NF_PROTO_FSP) == 0);
    assert(nf_protocol_available(NF_PROTO_SMB) == 0);
    assert(nf_protocol_available(NF_PROTO_SFTP) == 0);
    assert(strcmp(nf_protocol_name(NF_PROTO_FTP), "FTP") == 0);
    assert(strcmp(nf_protocol_name(NF_PROTO_SFTP), "SFTP") == 0);

    nf_session_t s;
    rx_data = "220 ready\r\n331 password required\r\n230 logged in\r\n200 binary\r\n221 bye\r\n";
    rx_pos = 0; tx_len = 0; tx_data[0] = 0;
    assert(nf_ftp_connect(&s, "192.168.1.2", 21, "testuser", "testpass") == 1);
    assert(s.connected == 1 && s.control_socket == 5);
    assert(strstr(tx_data, "USER testuser\r\n") != 0);
    assert(strstr(tx_data, "PASS testpass\r\n") != 0);
    assert(strstr(tx_data, "TYPE I\r\n") != 0);
    nf_disconnect(&s);
    assert(s.connected == 0 && s.control_socket == -1);
    assert(strstr(tx_data, "QUIT\r\n") != 0);
    return 0;
}
