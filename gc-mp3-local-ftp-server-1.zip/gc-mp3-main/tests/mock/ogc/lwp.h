#ifndef MOCK_LWP_H
#define MOCK_LWP_H
typedef unsigned long lwp_t;
static inline int LWP_CreateThread(lwp_t *id, void *(*entry)(void *), void *arg, void *stack, unsigned long stack_size, int prio) {
 (void)id; (void)entry; (void)arg; (void)stack; (void)stack_size; (void)prio; return 0;
}
#endif
