#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
TMP=${TMPDIR:-/tmp}/gcmp3-netfiles-test-$$
trap 'rm -f "$TMP"' EXIT
cc -std=gnu99 -Wall -Wextra -Werror -Wno-unused-parameter -I"$ROOT/tests/mock" -I"$ROOT/source" \
  "$ROOT/source/netfiles.c" "$ROOT/tests/netfiles_host_test.c" -o "$TMP"
"$TMP"
echo "OK: module netfiles compilable sur hote; contrat de disponibilite teste."
