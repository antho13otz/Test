#ifndef MOCK_GCCORE_H
#define MOCK_GCCORE_H
#include <stdint.h>
typedef uint8_t u8;
typedef uint32_t u32;
typedef int32_t s32;
typedef uint16_t u16;
#define ATTRIBUTE_ALIGN(n) __attribute__((aligned(n)))
#endif
