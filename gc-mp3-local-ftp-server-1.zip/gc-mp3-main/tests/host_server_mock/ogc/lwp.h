#ifndef HOST_LWP_H
#define HOST_LWP_H
#include <pthread.h>
typedef unsigned long lwp_t;
static inline int LWP_CreateThread(lwp_t *id, void *(*entry)(void *), void *arg, void *stack, unsigned long stack_size, int prio) {
 pthread_t t; (void)stack; (void)stack_size; (void)prio;
 int r = pthread_create(&t, NULL, entry, arg); if (!r) { pthread_detach(t); if (id) *id = (lwp_t)t; } return r ? -1 : 0;
}
#endif
