#ifndef MOCK_NETWORK_H
#define MOCK_NETWORK_H
#include <sys/types.h>
#include <sys/socket.h>
#include <stdint.h>
typedef int32_t s32;
typedef uint16_t u16;
s32 net_send(s32,const void*,s32,int);
s32 net_recv(s32,void*,s32,int);
s32 net_socket(int,int,int);
s32 net_connect(s32,struct sockaddr*,int);
s32 net_close(s32);
s32 net_bind(s32,struct sockaddr*,socklen_t);
s32 net_listen(s32,int);
s32 net_accept(s32,struct sockaddr*,socklen_t*);
s32 net_setsockopt(s32,int,int,const void*,socklen_t);
#endif
