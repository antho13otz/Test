/* GC-MP3 / Indigo : clients de fichiers reseau.
 * FTP RFC 959 est implemente ici. FSP, SMB et SFTP sont declares mais volontairement
 * desactives tant que leurs piles compatibles GameCube ne sont pas embarquees.
 * Ne jamais annoncer une connexion reussie pour un adaptateur absent. */
#include "netfiles.h"
#include <network.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>

#define NF_LINE 512
#define NF_IO   4096
static char nf_error[160];
static void nf_err(const char *s) { snprintf(nf_error, sizeof(nf_error), "%s", s ? s : "Erreur reseau"); }
const char *nf_last_error(void) { return nf_error; }
const char *nf_protocol_name(nf_protocol_t p) {
    switch (p) { case NF_PROTO_FTP: return "FTP"; case NF_PROTO_FSP: return "FSP"; case NF_PROTO_SMB: return "SMB"; case NF_PROTO_SFTP: return "SFTP"; default: return "?"; }
}
int nf_protocol_available(nf_protocol_t p) { return p == NF_PROTO_FTP; }

static int nf_send_all(int fd, const void *data, int len) {
    const char *p = (const char *)data;
    while (len > 0) { s32 n = net_send(fd, p, len, 0); if (n <= 0) return 0; p += n; len -= n; }
    return 1;
}
static int nf_recv_line(int fd, char *out, int cap) {
    int n = 0; char c;
    if (cap < 2) return -1;
    while (n < cap - 1) {
        s32 r = net_recv(fd, &c, 1, 0);
        if (r <= 0) return -1;
        if (c == '\n') break;
        if (c != '\r') out[n++] = c;
    }
    out[n] = 0; return n;
}
/* Lit une reponse FTP, y compris les reponses multilignes (123-... / 123 ...). */
static int nf_reply(int fd, char *message, int cap) {
    char line[NF_LINE]; int code = -1, first = 1;
    if (message && cap) message[0] = 0;
    for (;;) {
        int n = nf_recv_line(fd, line, sizeof(line));
        if (n < 3 || !isdigit((unsigned char)line[0]) || !isdigit((unsigned char)line[1]) || !isdigit((unsigned char)line[2])) return -1;
        if (first) { code = (line[0]-'0')*100 + (line[1]-'0')*10 + line[2]-'0'; first = 0; }
        if (message && cap) { size_t used = strlen(message); if (used + strlen(line) + 2 < (size_t)cap) { if (used) strcat(message, "\n"); strcat(message, line); } }
        if (line[3] != '-') break;
        /* Une ligne de fin commence par le meme code suivi d'une espace. */
        for (;;) {
            n = nf_recv_line(fd, line, sizeof(line));
            if (n < 0) return -1;
            if (n >= 4 && line[0] == (char)('0' + code/100) && line[1] == (char)('0' + (code/10)%10) && line[2] == (char)('0' + code%10) && line[3] == ' ') break;
        }
        if (message && cap) { size_t used = strlen(message); if (used + strlen(line) + 2 < (size_t)cap) { if (used) strcat(message, "\n"); strcat(message, line); } }
        break;
    }
    return code;
}
static int nf_command(nf_session_t *s, const char *cmd, char *reply, int cap) {
    char line[640];
    if (!s || !s->connected || s->control_socket < 0) { nf_err("FTP non connecte"); return -1; }
    if (snprintf(line, sizeof(line), "%s\r\n", cmd) >= (int)sizeof(line) || !nf_send_all(s->control_socket, line, (int)strlen(line))) { nf_err("Ecriture FTP impossible"); return -1; }
    int c = nf_reply(s->control_socket, reply, cap);
    if (c < 0) nf_err("Reponse FTP invalide ou connexion coupee");
    return c;
}
static int nf_safe_arg(const char *s) { return s && !strchr(s, '\r') && !strchr(s, '\n'); }
static int nf_data_socket(nf_session_t *s) {
    char reply[NF_LINE], cmd[32];
    int c = nf_command(s, "PASV", reply, sizeof(reply));
    if (c != 227) { nf_err("Le serveur FTP refuse le mode passif (PASV)"); return -1; }
    char *p = strchr(reply, '('); if (!p) { nf_err("Reponse PASV invalide"); return -1; }
    int h1,h2,h3,h4,p1,p2;
    if (sscanf(p+1, "%d,%d,%d,%d,%d,%d", &h1,&h2,&h3,&h4,&p1,&p2) != 6 || h1<0 || h1>255 || h2<0 || h2>255 || h3<0 || h3>255 || h4<0 || h4>255 || p1<0 || p1>255 || p2<0 || p2>255) { nf_err("Adresse PASV invalide"); return -1; }
    /* Certains serveurs annoncent une IP privee incorrecte: on se reconnecte a l'IP du controle. */
    struct in_addr advertised; advertised.s_addr = htonl(((unsigned)h1<<24)|((unsigned)h2<<16)|((unsigned)h3<<8)|(unsigned)h4);
    struct in_addr control; control.s_addr = inet_addr(s->host);
    if ((advertised.s_addr == INADDR_NONE) || h1 == 0 || (h1 == 10) || (h1 == 192 && h2 == 168) || (h1 == 172 && h2 >= 16 && h2 <= 31)) advertised = control;
    int fd = net_socket(AF_INET, SOCK_STREAM, 0); if (fd < 0) { nf_err("Socket de donnees indisponible"); return -1; }
    struct sockaddr_in sa; memset(&sa, 0, sizeof(sa)); sa.sin_family = AF_INET; sa.sin_addr = advertised; sa.sin_port = htons((u16)(p1*256+p2));
    if (net_connect(fd, (struct sockaddr *)&sa, sizeof(sa)) < 0) { net_close(fd); nf_err("Connexion FTP de donnees impossible"); return -1; }
    (void)cmd; return fd;
}
static int nf_path_cmd(nf_session_t *s, const char *verb, const char *path, int expected) {
    char cmd[640], reply[NF_LINE];
    if (!nf_safe_arg(path) || !path || strlen(path) > 500) { nf_err("Chemin distant invalide"); return 0; }
    snprintf(cmd, sizeof(cmd), "%s %s", verb, path);
    int c = nf_command(s, cmd, reply, sizeof(reply));
    if (c != expected && !(expected == 250 && c == 257)) { nf_err(reply[0] ? reply : "Commande FTP refusee"); return 0; }
    return 1;
}
int nf_ftp_connect(nf_session_t *s, const char *ipv4, uint16_t port, const char *user, const char *password) {
    struct sockaddr_in sa; char reply[NF_LINE], cmd[256]; int fd;
    if (!s || !ipv4 || !user || !password || !nf_safe_arg(user) || !nf_safe_arg(password)) { nf_err("Parametres FTP invalides"); return 0; }
    if (strlen(ipv4) >= sizeof(s->host) || strlen(user) >= sizeof(s->user) || strlen(password) >= sizeof(s->password)) { nf_err("Parametre trop long"); return 0; }
    struct in_addr addr; addr.s_addr = inet_addr(ipv4); if (addr.s_addr == INADDR_NONE) { nf_err("Utilise une adresse IPv4 numerique"); return 0; }
    memset(s, 0, sizeof(*s)); s->protocol = NF_PROTO_FTP; s->control_socket = -1;
    strcpy(s->host, ipv4); strcpy(s->user, user); strcpy(s->password, password); s->port = port ? port : 21;
    fd = net_socket(AF_INET, SOCK_STREAM, 0); if (fd < 0) { nf_err("Creation de socket impossible"); return 0; }
    memset(&sa, 0, sizeof(sa)); sa.sin_family = AF_INET; sa.sin_addr = addr; sa.sin_port = htons(s->port);
    if (net_connect(fd, (struct sockaddr *)&sa, sizeof(sa)) < 0) { net_close(fd); nf_err("Connexion au serveur FTP impossible"); return 0; }
    s->control_socket = fd;
    s->connected = 1; /* nf_command exige une session marquee connectee */
    int c = nf_reply(fd, reply, sizeof(reply)); if (c != 220) { nf_err(reply[0] ? reply : "Banniere FTP inattendue"); nf_disconnect(s); return 0; }
    snprintf(cmd, sizeof(cmd), "USER %s", user); c = nf_command(s, cmd, reply, sizeof(reply));
    if (c == 331) { snprintf(cmd, sizeof(cmd), "PASS %s", password); c = nf_command(s, cmd, reply, sizeof(reply)); }
    if (c != 230) { nf_err(reply[0] ? reply : "Authentification FTP refusee"); nf_disconnect(s); return 0; }
    c = nf_command(s, "TYPE I", reply, sizeof(reply)); if (c != 200) { nf_err("Mode binaire FTP indisponible"); nf_disconnect(s); return 0; }
    s->connected = 1; strcpy(s->remote_cwd, "/"); nf_error[0] = 0; return 1;
}
void nf_disconnect(nf_session_t *s) {
    if (!s) return;
    if (s->control_socket >= 0) { if (s->connected) { char reply[NF_LINE]; (void)nf_command(s, "QUIT", reply, sizeof(reply)); } net_close(s->control_socket); }
    s->control_socket = -1; s->connected = 0;
}
int nf_ftp_cwd(nf_session_t *s, const char *remote_dir) {
    char cmd[640], reply[NF_LINE];
    if (!nf_safe_arg(remote_dir) || !remote_dir || strlen(remote_dir) > 500) { nf_err("Dossier distant invalide"); return 0; }
    snprintf(cmd, sizeof(cmd), "CWD %s", remote_dir);
    int c = nf_command(s, cmd, reply, sizeof(reply));
    if (c != 250) { nf_err(reply[0] ? reply : "Changement de dossier FTP refuse"); return 0; }
    snprintf(s->remote_cwd, sizeof(s->remote_cwd), "%.255s", remote_dir);
    nf_error[0] = 0; return 1;
}
int nf_ftp_list(nf_session_t *s, nf_entry_t *entries, int capacity, int *count) {
    char reply[NF_LINE], line[NF_LINE]; int data, c, n = 0;
    if (!entries || capacity < 1 || !count) { nf_err("Tampon de liste invalide"); return 0; }
    *count = 0; data = nf_data_socket(s); if (data < 0) return 0;
    c = nf_command(s, "LIST", reply, sizeof(reply)); if (c != 125 && c != 150) { net_close(data); nf_err(reply); return 0; }
    /* LIST UNIX courant; les serveurs aux formats non POSIX sont signales plutot que mal parses. */
    while ((c = nf_recv_line(data, line, sizeof(line))) >= 0) {
        char perm[16], owner[64], group[64], name[256]; unsigned long long size; int links; char month[16], day[16], when[16];
        if (sscanf(line, "%15s %d %63s %63s %llu %15s %15s %15s %255[^\n]", perm, &links, owner, group, &size, month, day, when, name) == 9) {
            if (!strcmp(name, ".") || !strcmp(name, "..")) continue;
            if (n >= capacity) continue;
            snprintf(entries[n].name, sizeof(entries[n].name), "%.127s", name); entries[n].is_dir = perm[0] == 'd'; entries[n].size = size > 0xFFFFFFFFULL ? 0xFFFFFFFFU : (uint32_t)size; n++;
        }
    }
    net_close(data); c = nf_reply(s->control_socket, reply, sizeof(reply));
    if (c != 226 && c != 250) { nf_err(reply); return 0; }
    *count = n; nf_error[0] = 0; return 1;
}
static int nf_transfer(nf_session_t *s, const char *verb, const char *remote, const char *local, int upload) {
    char cmd[640], reply[NF_LINE], buf[NF_IO]; FILE *fp; int data, c, ok = 1;
    if (!nf_safe_arg(remote) || !remote || strlen(remote) > 500 || !local) { nf_err("Chemin de transfert invalide"); return 0; }
    fp = fopen(local, upload ? "rb" : "wb"); if (!fp) { nf_err("Ouverture du fichier local impossible"); return 0; }
    data = nf_data_socket(s); if (data < 0) { fclose(fp); return 0; }
    snprintf(cmd, sizeof(cmd), "%s %s", verb, remote); c = nf_command(s, cmd, reply, sizeof(reply));
    if (c != 125 && c != 150) { net_close(data); fclose(fp); nf_err(reply); return 0; }
    if (upload) {
        size_t n; while ((n = fread(buf, 1, sizeof(buf), fp)) > 0) if (!nf_send_all(data, buf, (int)n)) { ok = 0; break; }
        if (ferror(fp)) ok = 0;
    } else {
        for (;;) { s32 n = net_recv(data, buf, sizeof(buf), 0); if (n == 0) break; if (n < 0 || fwrite(buf, 1, (size_t)n, fp) != (size_t)n) { ok = 0; break; } }
    }
    net_close(data); if (fclose(fp) != 0) ok = 0;
    c = nf_reply(s->control_socket, reply, sizeof(reply)); if (c != 226 && c != 250) ok = 0;
    if (!ok) { if (!upload) remove(local); nf_err(reply[0] ? reply : "Transfert FTP interrompu"); return 0; }
    nf_error[0] = 0; return 1;
}
int nf_ftp_download(nf_session_t *s, const char *r, const char *l) { return nf_transfer(s, "RETR", r, l, 0); }
int nf_ftp_upload(nf_session_t *s, const char *l, const char *r) { return nf_transfer(s, "STOR", r, l, 1); }
int nf_ftp_rename(nf_session_t *s, const char *oldp, const char *newp) {
    char cmd[640], reply[NF_LINE]; int c;
    if (!nf_safe_arg(oldp) || !nf_safe_arg(newp) || !oldp || !newp || strlen(oldp)>500 || strlen(newp)>500) { nf_err("Chemin de renommage invalide"); return 0; }
    snprintf(cmd, sizeof(cmd), "RNFR %s", oldp); c = nf_command(s, cmd, reply, sizeof(reply)); if (c != 350) { nf_err(reply); return 0; }
    snprintf(cmd, sizeof(cmd), "RNTO %s", newp); c = nf_command(s, cmd, reply, sizeof(reply)); if (c != 250) { nf_err(reply); return 0; } nf_error[0]=0; return 1;
}
int nf_ftp_delete(nf_session_t *s, const char *p) { return nf_path_cmd(s, "DELE", p, 250); }
int nf_ftp_mkdir(nf_session_t *s, const char *p) { return nf_path_cmd(s, "MKD", p, 257); }
int nf_ftp_rmdir(nf_session_t *s, const char *p) { return nf_path_cmd(s, "RMD", p, 250); }
