#ifndef GCMP3_NETSERVER_H
#define GCMP3_NETSERVER_H
/* Serveur FTP local en lecture/ecriture sur la carte SD. Port de controle 2121.
 * Lancement apres if_config(), aucun element d'interface requis. */
int gcmp3_ftp_server_start(const char *ipv4);
int gcmp3_ftp_server_running(void);
const char *gcmp3_ftp_server_status(void);
#endif
