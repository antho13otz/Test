/* GC-MP3 local FTP server (RFC 959 subset), for LAN-only file transfers.
 * Uses libogc/lwIP sockets and libfat stdio/dirent. No TLS: do not expose to WAN.
 */
#include "netserver.h"
#include <gccore.h>
#include <ogc/lwp.h>
#include <network.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <unistd.h>
#include <errno.h>

#define FTP_PORT 2121
#define FTP_PASV_FIRST 50000
#define FTP_PASV_COUNT 8
#define FTP_LINE 1024
#define FTP_IO 4096
#define FTP_ROOT "sd:/"
#define FTP_USER "gc-mp3"
#define FTP_PASS "indigo"

static lwp_t ftp_thread_id;
static u8 ftp_thread_stack[24 * 1024] ATTRIBUTE_ALIGN(32);
static volatile int ftp_started = 0;
static volatile int ftp_running = 0;
static char ftp_ip[16] = "0.0.0.0";
static char ftp_status[128] = "FTP inactif";
static unsigned ftp_pasv_next = 0;

static int send_all(int fd, const void *buf, int len) {
    const char *p = (const char *)buf;
    while (len > 0) {
        s32 n = net_send(fd, p, len, 0);
        if (n <= 0) return 0;
        p += n; len -= n;
    }
    return 1;
}
static int send_text(int fd, const char *s) { return send_all(fd, s, (int)strlen(s)); }
static int recv_line(int fd, char *out, int cap) {
    int n = 0; char c;
    if (cap < 2) return -1;
    while (n < cap - 1) {
        s32 r = net_recv(fd, &c, 1, 0);
        if (r <= 0) return -1;
        if (c == '\n') break;
        if (c != '\r' && c != 0) out[n++] = c;
    }
    out[n] = 0;
    /* Drain overlong commands to keep command framing synchronized. */
    if (n == cap - 1 && out[n - 1] != '\n') {
        while (net_recv(fd, &c, 1, 0) > 0 && c != '\n') {}
        return -2;
    }
    return n;
}
static int valid_name(const char *s) {
    return s && !strchr(s, '\r') && !strchr(s, '\n');
}
/* Convert FTP path to a path under sd:/; reject traversal and drive changes. */
static int map_path(const char *cwd, const char *arg, char *out, size_t cap) {
    char joined[768], norm[768]; char *save = NULL; char *tok;
    if (!arg || !valid_name(arg) || strchr(arg, ':') || strchr(arg, '\\')) return 0;
    if (arg[0] == '/') snprintf(joined, sizeof(joined), "%s", arg);
    else if (!*arg) snprintf(joined, sizeof(joined), "%s", cwd);
    else snprintf(joined, sizeof(joined), "%s/%s", cwd, arg);
    norm[0] = 0;
    tok = strtok_r(joined, "/", &save);
    while (tok) {
        if (!strcmp(tok, ".") || !*tok) { tok = strtok_r(NULL, "/", &save); continue; }
        if (!strcmp(tok, "..")) return 0;
        if (strstr(tok, "..")) { /* allow names like song..mp3, reject only traversal token above */ }
        if (strlen(norm) + strlen(tok) + 2 >= sizeof(norm)) return 0;
        if (norm[0]) strcat(norm, "/");
        strcat(norm, tok);
        tok = strtok_r(NULL, "/", &save);
    }
    if (snprintf(out, cap, "%s%s%s", FTP_ROOT, norm[0] ? norm : "", norm[0] ? "" : "") >= (int)cap) return 0;
    return 1;
}
static int ftp_reply(int fd, int code, const char *msg) {
    char b[FTP_LINE]; snprintf(b, sizeof(b), "%d %s\r\n", code, msg ? msg : ""); return send_text(fd, b);
}
static int open_passive(int control_fd, struct in_addr bind_ip) {
    int fd = -1; struct sockaddr_in sa; unsigned i;
    for (i = 0; i < FTP_PASV_COUNT; i++) {
        unsigned port = FTP_PASV_FIRST + ((ftp_pasv_next + i) % FTP_PASV_COUNT);
        fd = net_socket(AF_INET, SOCK_STREAM, 0);
        if (fd < 0) continue;
        { u32 one = 1; net_setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one)); }
        memset(&sa, 0, sizeof(sa)); sa.sin_family = AF_INET; sa.sin_addr.s_addr = htonl(INADDR_ANY); sa.sin_port = htons((u16)port);
        if (net_bind(fd, (struct sockaddr *)&sa, sizeof(sa)) == 0 && net_listen(fd, 1) == 0) {
            char msg[160]; ftp_pasv_next = (port - FTP_PASV_FIRST + 1) % FTP_PASV_COUNT;
            snprintf(msg, sizeof(msg), "Entering Passive Mode (%u,%u,%u,%u,%u,%u)",
                     (unsigned)((ntohl(bind_ip.s_addr)>>24)&255), (unsigned)((ntohl(bind_ip.s_addr)>>16)&255),
                     (unsigned)((ntohl(bind_ip.s_addr)>>8)&255), (unsigned)(ntohl(bind_ip.s_addr)&255), port/256, port%256);
            if (!ftp_reply(control_fd, 227, msg)) { net_close(fd); return -1; }
            return fd;
        }
        net_close(fd); fd = -1;
    }
    ftp_reply(control_fd, 425, "Cannot open passive data listener");
    return -1;
}
static int accept_data(int passive_fd) {
    struct sockaddr_in peer; socklen_t n = sizeof(peer);
    int fd = net_accept(passive_fd, (struct sockaddr *)&peer, &n);
    net_close(passive_fd);
    return fd;
}
static void list_dir(int ctl, int *pasv, const char *cwd, const char *path, int names_only) {
    DIR *d; struct dirent *e; char local[768], line[FTP_LINE], pathbuf[768]; int data;
    struct stat st;
    if (*pasv < 0) { ftp_reply(ctl, 425, "Use PASV first"); return; }
    path = path ? path : "";
    /* Clients sometimes send LIST -la /folder; ignore LIST option tokens. */
    if (path[0] == '-') { const char *sp = strchr(path, ' '); path = sp ? sp + 1 : ""; while (*path == ' ') path++; }
    snprintf(pathbuf, sizeof(pathbuf), "%.767s", path); path = pathbuf;
    if (!map_path(cwd, path, local, sizeof(local))) { net_close(*pasv); *pasv=-1; ftp_reply(ctl, 550, "Invalid path"); return; }
    d = opendir(local);
    if (!d) { net_close(*pasv); *pasv=-1; ftp_reply(ctl, 550, "Cannot open directory"); return; }
    if (!ftp_reply(ctl, 150, "Opening data connection")) { closedir(d); net_close(*pasv); *pasv=-1; return; }
    data = accept_data(*pasv); *pasv = -1;
    if (data < 0) { closedir(d); ftp_reply(ctl, 425, "Data connection failed"); return; }
    while ((e = readdir(d)) != NULL) {
        if (!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
        if (names_only) snprintf(line, sizeof(line), "%s\r\n", e->d_name);
        else {
            char child[768]; int isdir = 0; unsigned long size = 0;
            if (snprintf(child, sizeof(child), "%s/%s", local, e->d_name) < (int)sizeof(child) && stat(child, &st) == 0) { isdir = S_ISDIR(st.st_mode); size = (unsigned long)st.st_size; }
            snprintf(line, sizeof(line), "%crw-r--r-- 1 gc gc %10lu Jan 01 00:00 %s\r\n", isdir ? 'd' : '-', size, e->d_name);
        }
        if (!send_text(data, line)) break;
    }
    closedir(d); net_close(data); ftp_reply(ctl, 226, "Transfer complete");
}
static void transfer_file(int ctl, int *pasv, const char *cwd, const char *arg, int upload) {
    char local[768], tmp_path[800], buf[FTP_IO]; FILE *f; int data, ok = 1; size_t n;
    if (*pasv < 0) { ftp_reply(ctl, 425, "Use PASV first"); return; }
    if (!map_path(cwd, arg, local, sizeof(local))) { net_close(*pasv); *pasv=-1; ftp_reply(ctl, 550, "Invalid path"); return; }
    if (upload) {
        if (snprintf(tmp_path, sizeof(tmp_path), "%s.gcmp3part", local) >= (int)sizeof(tmp_path)) { net_close(*pasv); *pasv=-1; ftp_reply(ctl, 550, "Path too long"); return; }
        remove(tmp_path);
        f = fopen(tmp_path, "wb");
    } else f = fopen(local, "rb");
    if (!f) { net_close(*pasv); *pasv=-1; ftp_reply(ctl, 550, "Cannot open file"); return; }
    if (!ftp_reply(ctl, 150, upload ? "Ready to receive file" : "Opening file data connection")) { fclose(f); net_close(*pasv); *pasv=-1; if (upload) remove(tmp_path); return; }
    data = accept_data(*pasv); *pasv = -1;
    if (data < 0) { fclose(f); if (upload) remove(tmp_path); ftp_reply(ctl, 425, "Data connection failed"); return; }
    if (upload) {
        for (;;) { s32 r = net_recv(data, buf, sizeof(buf), 0); if (r == 0) break; if (r < 0 || fwrite(buf, 1, (size_t)r, f) != (size_t)r) { ok=0; break; } }
    } else {
        while ((n = fread(buf, 1, sizeof(buf), f)) > 0) if (!send_all(data, buf, (int)n)) { ok=0; break; }
        if (ferror(f)) ok=0;
    }
    net_close(data); if (fclose(f) != 0) ok=0;
    if (upload) {
        if (ok && rename(tmp_path, local) != 0) ok=0;
        if (!ok) remove(tmp_path);
    }
    ftp_reply(ctl, ok ? 226 : 451, ok ? "Transfer complete" : "Local file or network error");
}
static void handle_client(int ctl, struct in_addr bind_ip) {
    char line[FTP_LINE], cwd[512] = "/", arg[768], local[768], oldpath[768];
    int pasv = -1, logged = 0, user_ok = 0, rnfr = 0;
    ftp_reply(ctl, 220, "GC-MP3 Indigo FTP server ready; local LAN only");
    while (1) {
        int n = recv_line(ctl, line, sizeof(line)); char *cmd;
        if (n < 0) break;
        if (n == -2) { ftp_reply(ctl, 500, "Command too long"); continue; }
        cmd = line; while (*cmd && !isspace((unsigned char)*cmd)) { *cmd=(char)toupper((unsigned char)*cmd); cmd++; }
        if (*cmd) *cmd++ = 0;
        while (*cmd==' ') cmd++;
        snprintf(arg, sizeof(arg), "%.767s", cmd);
        if (!strcmp(line, "USER")) { user_ok = !strcmp(arg, FTP_USER); logged = 0; ftp_reply(ctl, 331, "Password required"); }
        else if (!strcmp(line, "PASS")) { logged = user_ok && !strcmp(arg, FTP_PASS); ftp_reply(ctl, logged ? 230 : 530, logged ? "Logged in" : "Authentication failed"); }
        else if (!strcmp(line, "QUIT")) { ftp_reply(ctl, 221, "Goodbye"); break; }
        else if (!strcmp(line, "NOOP")) ftp_reply(ctl, 200, "OK");
        else if (!strcmp(line, "SYST")) ftp_reply(ctl, 215, "UNIX Type: L8");
        else if (!strcmp(line, "FEAT")) { send_text(ctl, "211-Features\r\n PASV\r\n SIZE\r\n211 End\r\n"); }
        else if (!strcmp(line, "TYPE")) ftp_reply(ctl, 200, "Type set");
        else if (!logged) ftp_reply(ctl, 530, "Send USER and PASS first");
        else if (!strcmp(line, "PWD") || !strcmp(line, "XPWD")) { char b[600]; snprintf(b, sizeof(b), "\"%s\" is current directory", cwd); ftp_reply(ctl, 257, b); }
        else if (!strcmp(line, "CWD") && !strcmp(arg, "..")) { char *slash = strrchr(cwd, '/'); if (slash && slash != cwd) *slash=0; else strcpy(cwd,"/"); ftp_reply(ctl,250,"Directory changed"); }
        else if (!strcmp(line, "CWD")) {
            struct stat st;
            if (map_path(cwd, arg, local, sizeof(local)) && stat(local, &st)==0 && S_ISDIR(st.st_mode)) {
                /* store path relative to SD root */
                const char *rel = local + strlen(FTP_ROOT); snprintf(cwd, sizeof(cwd), "/%s", rel); if (!strcmp(cwd, "/")) strcpy(cwd, "/"); ftp_reply(ctl, 250, "Directory changed");
            } else ftp_reply(ctl, 550, "Directory unavailable");
        }
        else if (!strcmp(line, "CDUP")) { char *slash = strrchr(cwd, '/'); if (slash && slash != cwd) *slash=0; else strcpy(cwd,"/"); ftp_reply(ctl, 250, "Directory changed"); }
        else if (!strcmp(line, "PASV")) { if (pasv >= 0) net_close(pasv); pasv=open_passive(ctl, bind_ip); }
        else if (!strcmp(line, "LIST") || !strcmp(line, "NLST")) list_dir(ctl, &pasv, cwd, arg, !strcmp(line,"NLST"));
        else if (!strcmp(line, "RETR")) transfer_file(ctl, &pasv, cwd, arg, 0);
        else if (!strcmp(line, "STOR")) transfer_file(ctl, &pasv, cwd, arg, 1);
        else if (!strcmp(line, "SIZE")) { struct stat st; if (map_path(cwd,arg,local,sizeof(local)) && stat(local,&st)==0 && !S_ISDIR(st.st_mode)) { char b[96]; snprintf(b,sizeof(b),"%lu",(unsigned long)st.st_size); ftp_reply(ctl,213,b); } else ftp_reply(ctl,550,"File unavailable"); }
        else if (!strcmp(line, "DELE")) { if (map_path(cwd,arg,local,sizeof(local)) && remove(local)==0) ftp_reply(ctl,250,"File deleted"); else ftp_reply(ctl,550,"Delete failed"); }
        else if (!strcmp(line, "MKD") || !strcmp(line, "XMKD")) { if (map_path(cwd,arg,local,sizeof(local)) && mkdir(local,0777)==0) { char b[600]; snprintf(b,sizeof(b),"\"%.500s\" created",arg); ftp_reply(ctl,257,b); } else ftp_reply(ctl,550,"Create directory failed"); }
        else if (!strcmp(line, "RMD") || !strcmp(line, "XRMD")) { if (map_path(cwd,arg,local,sizeof(local)) && rmdir(local)==0) ftp_reply(ctl,250,"Directory removed"); else ftp_reply(ctl,550,"Remove directory failed"); }
        else if (!strcmp(line, "RNFR")) { if (map_path(cwd,arg,oldpath,sizeof(oldpath)) && access(oldpath,F_OK)==0) { rnfr=1; ftp_reply(ctl,350,"Send RNTO next"); } else { rnfr=0; ftp_reply(ctl,550,"Source unavailable"); } }
        else if (!strcmp(line, "RNTO")) { if (rnfr && map_path(cwd,arg,local,sizeof(local)) && rename(oldpath,local)==0) ftp_reply(ctl,250,"Rename successful"); else ftp_reply(ctl,550,"Rename failed"); rnfr=0; }
        else if (!strcmp(line, "OPTS")) ftp_reply(ctl,200,"Option accepted");
        else if (!strcmp(line, "ABOR")) { if (pasv>=0) { net_close(pasv); pasv=-1; } ftp_reply(ctl,226,"Abort successful"); }
        else ftp_reply(ctl,502,"Command not implemented");
    }
    if (pasv >= 0) net_close(pasv);
}
static void *ftp_server_thread(void *unused) {
    int listener; struct sockaddr_in sa; (void)unused;
    listener = net_socket(AF_INET, SOCK_STREAM, 0);
    if (listener < 0) { strcpy(ftp_status,"FTP: socket failed"); ftp_running=0; return NULL; }
    { u32 one = 1; net_setsockopt(listener, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one)); }
    memset(&sa,0,sizeof(sa)); sa.sin_family=AF_INET; sa.sin_addr.s_addr=htonl(INADDR_ANY); sa.sin_port=htons(FTP_PORT);
    if (net_bind(listener,(struct sockaddr *)&sa,sizeof(sa))<0 || net_listen(listener,2)<0) {
        net_close(listener); strcpy(ftp_status,"FTP: port 2121 unavailable"); ftp_running=0; return NULL;
    }
    ftp_running=1; strcpy(ftp_status,"FTP actif sur le port 2121 (LAN)");
    while (1) {
        struct sockaddr_in peer; socklen_t len=sizeof(peer); int ctl=net_accept(listener,(struct sockaddr *)&peer,&len);
        if (ctl < 0) continue;
        { struct in_addr addr; addr.s_addr=inet_addr(ftp_ip); handle_client(ctl,addr); }
        net_close(ctl);
    }
    return NULL;
}
int gcmp3_ftp_server_start(const char *ipv4) {
    if (ftp_started) return ftp_running || strcmp(ftp_status,"FTP: port 2121 unavailable") != 0;
    if (!ipv4 || !*ipv4 || strlen(ipv4) >= sizeof(ftp_ip)) return 0;
    strcpy(ftp_ip,ipv4); ftp_started=1; strcpy(ftp_status,"Démarrage du serveur FTP...");
    if (LWP_CreateThread(&ftp_thread_id,ftp_server_thread,NULL,ftp_thread_stack,sizeof(ftp_thread_stack),40)<0) {
        ftp_started=0; ftp_running=0; strcpy(ftp_status,"FTP: création du thread impossible"); return 0;
    }
    return 1;
}
int gcmp3_ftp_server_running(void) { return ftp_running; }
const char *gcmp3_ftp_server_status(void) { return ftp_status; }
