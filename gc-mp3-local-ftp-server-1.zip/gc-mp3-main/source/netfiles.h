#ifndef GCMP3_NETFILES_H
#define GCMP3_NETFILES_H
#include <stddef.h>
#include <stdint.h>

/* Interface reseau pour l'explorateur GC-MP3. Les operations sont synchrones:
 * les appeler depuis un thread de travail, jamais dans la boucle GX. */
typedef enum {
    NF_PROTO_FTP = 0,
    NF_PROTO_FSP,
    NF_PROTO_SMB,
    NF_PROTO_SFTP
} nf_protocol_t;

typedef struct {
    nf_protocol_t protocol;
    char host[64];             /* IPv4 litterale pour FTP dans cette version */
    uint16_t port;
    char user[64];
    char password[96];
    char remote_cwd[256];
    int control_socket;
    int connected;
} nf_session_t;

typedef struct {
    char name[128];
    uint32_t size;
    unsigned is_dir : 1;
} nf_entry_t;

/* 1 = protocole disponible dans cette version, 0 = adaptateur non implemente. */
int nf_protocol_available(nf_protocol_t protocol);
const char *nf_protocol_name(nf_protocol_t protocol);
const char *nf_last_error(void);

/* FTP (RFC 959): controle en clair; utiliser uniquement sur un reseau de confiance. */
int nf_ftp_connect(nf_session_t *s, const char *ipv4, uint16_t port,
                   const char *user, const char *password);
void nf_disconnect(nf_session_t *s);
int nf_ftp_cwd(nf_session_t *s, const char *remote_dir);
int nf_ftp_list(nf_session_t *s, nf_entry_t *entries, int capacity, int *count);
int nf_ftp_download(nf_session_t *s, const char *remote_path, const char *local_path);
int nf_ftp_upload(nf_session_t *s, const char *local_path, const char *remote_path);
int nf_ftp_rename(nf_session_t *s, const char *old_path, const char *new_path);
int nf_ftp_delete(nf_session_t *s, const char *remote_path);
int nf_ftp_mkdir(nf_session_t *s, const char *remote_path);
int nf_ftp_rmdir(nf_session_t *s, const char *remote_path);

#endif
